#include <iostream>
using namespace std;
int main()
{
	int i = 40;
	cout<<"Hello World"<<endl;
	return 0;
}
